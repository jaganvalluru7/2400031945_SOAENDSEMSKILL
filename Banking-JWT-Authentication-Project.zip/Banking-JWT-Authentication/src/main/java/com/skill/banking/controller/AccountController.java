package com.skill.banking.controller;

import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/account")
public class AccountController {
    @GetMapping("/details")
    public Map<String, Object> accountDetails(Authentication authentication) {
        // Demonstration data only. Do not store real banking information in this sample.
        return Map.of("accountHolder", authentication.getName(),
                "accountNumber", "XXXX-XXXX-1234",
                "accountType", "Savings",
                "availableBalance", 25000.00,
                "currency", "INR");
    }
}
