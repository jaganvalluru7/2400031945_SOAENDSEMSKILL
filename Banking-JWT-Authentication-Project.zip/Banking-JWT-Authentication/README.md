# Banking API - JWT Token-Based Authentication

Academic Skill Experiment 4 for SOA Programming and Microservices (24SDCS03).

## What this project demonstrates
- `POST /api/auth/login` checks a username and password and returns a signed JWT.
- `GET /account/details` is protected and requires `Authorization: Bearer <token>`.
- JWT signature and expiry are checked on every protected request.
- The application is stateless: it does not create an HTTP login session.

## Requirements
- JDK 21
- Maven 3.6+ (or import the project as an existing Maven project in STS)

## Run in Spring Tool Suite (STS)
1. Extract the ZIP file.
2. Open STS and choose **File > Import > Maven > Existing Maven Projects**.
3. Select the extracted `Banking-JWT-Authentication` folder.
4. Wait for Maven dependencies to download.
5. Right-click `BankingJwtApplication.java` > **Run As > Spring Boot App**.
6. The API runs at `http://localhost:8080`.

You can also run it from a terminal in the project folder:
```bash
mvn spring-boot:run
```

## Demo login
For this classroom example only:
- Username: `customer`
- Password: `bank123`

### Test 1: Login and obtain a token
```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d "{\"username\":\"customer\",\"password\":\"bank123\"}"
```
Copy the `token` value from the JSON response.

### Test 2: Access account details with a valid token
```bash
curl http://localhost:8080/account/details \
  -H "Authorization: Bearer PASTE_TOKEN_HERE"
```
Expected: HTTP 200 and sample account details.

### Test 3: Access without a token
```bash
curl -i http://localhost:8080/account/details
```
Expected: HTTP 401 Unauthorized.

### Test 4: Access with an invalid token
```bash
curl -i http://localhost:8080/account/details \
  -H "Authorization: Bearer invalid.token.value"
```
Expected: HTTP 401 Unauthorized.

### Test 5: Expired token
The configured token lifetime is 15 minutes. Wait until a token expires, then call `/account/details` with it.
Expected: HTTP 401 Unauthorized.

## Postman steps
1. Create a POST request to `http://localhost:8080/api/auth/login`.
2. Select **Body > raw > JSON** and enter:
   `{"username":"customer","password":"bank123"}`
3. Send the request and copy the `token`.
4. Create a GET request to `http://localhost:8080/account/details`.
5. Under **Authorization**, choose **Bearer Token** and paste the token.
6. Send. Remove the token or replace it with a wrong value to test the 401 cases.

## Important security note
This is a learning/demo project. It uses an in-memory demo user and sample account data, not a real bank database. The JWT secret in `application.properties` is only a placeholder for local practice. For real deployment, use HTTPS, a strong secret from environment/secret management, persistent users, rate limiting, audit logging, and carefully designed account-level authorization. Never commit production secrets or use this sample credentials in a real system.
